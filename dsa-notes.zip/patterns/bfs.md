# 📚 DSA Pattern: BFS (Graph & Tree)

## 📖 Pattern Details
[Explain the pattern: when to use, key insights, complexity.]

---

## 📝 Problems
- [Binary Tree Level Order Traversal](https://leetcode.com/problems/binary-tree-level-order-traversal/)
- [Word Ladder](https://leetcode.com/problems/word-ladder/)
- [Number of Islands](https://leetcode.com/problems/number-of-islands/)

---

## 💡 Approach / Notes
[Write general approach and variations here]

---

## 💻 Solutions

<details>
<summary>Python</summary>

```python

```
</details>

<details>
<summary>C++</summary>

```cpp

```
</details>

<details>
<summary>Java</summary>

```java

```
</details>

<details>
<summary>JavaScript</summary>

```javascript

```
</details>

