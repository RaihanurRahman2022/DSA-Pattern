# 📚 DSA Pattern: Fast & Slow Pointers

## 📖 Pattern Details
[Explain the pattern: when to use, key insights, complexity.]

---

## 📝 Problems
- [Linked List Cycle](https://leetcode.com/problems/linked-list-cycle/)
- [Happy Number](https://leetcode.com/problems/happy-number/)
- [Palindrome Linked List](https://leetcode.com/problems/palindrome-linked-list/)

---

## 💡 Approach / Notes
[Write general approach and variations here]

---

## 💻 Solutions

<details>
<summary>Python</summary>

```python

```
</details>

<details>
<summary>C++</summary>

```cpp

```
</details>

<details>
<summary>Java</summary>

```java

```
</details>

<details>
<summary>JavaScript</summary>

```javascript

```
</details>

