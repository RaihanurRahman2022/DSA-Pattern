# 📚 DSA Pattern: Two Pointers

## 📖 Pattern Details
[Explain the pattern: when to use, key insights, complexity.]

---

## 📝 Problems
- [Two Sum II](https://leetcode.com/problems/two-sum-ii-input-array-is-sorted/)
- [Container With Most Water](https://leetcode.com/problems/container-with-most-water/)
- [3Sum](https://leetcode.com/problems/3sum/)

---

## 💡 Approach / Notes
[Write general approach and variations here]

---

## 💻 Solutions

<details>
<summary>Python</summary>

```python

```
</details>

<details>
<summary>C++</summary>

```cpp

```
</details>

<details>
<summary>Java</summary>

```java

```
</details>

<details>
<summary>JavaScript</summary>

```javascript

```
</details>

