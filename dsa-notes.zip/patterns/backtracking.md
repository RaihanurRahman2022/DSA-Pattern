# 📚 DSA Pattern: Backtracking

## 📖 Pattern Details
[Explain the pattern: when to use, key insights, complexity.]

---

## 📝 Problems
- [N-Queens](https://leetcode.com/problems/n-queens/)
- [Generate Parentheses](https://leetcode.com/problems/generate-parentheses/)
- [Word Search](https://leetcode.com/problems/word-search/)

---

## 💡 Approach / Notes
[Write general approach and variations here]

---

## 💻 Solutions

<details>
<summary>Python</summary>

```python

```
</details>

<details>
<summary>C++</summary>

```cpp

```
</details>

<details>
<summary>Java</summary>

```java

```
</details>

<details>
<summary>JavaScript</summary>

```javascript

```
</details>

