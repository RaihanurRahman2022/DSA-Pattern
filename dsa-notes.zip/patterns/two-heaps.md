# 📚 DSA Pattern: Two Heaps

## 📖 Pattern Details
[Explain the pattern: when to use, key insights, complexity.]

---

## 📝 Problems
- [Find Median from Data Stream](https://leetcode.com/problems/find-median-from-data-stream/)
- [Sliding Window Median](https://leetcode.com/problems/sliding-window-median/)
- [IPO](https://leetcode.com/problems/ipo/)

---

## 💡 Approach / Notes
[Write general approach and variations here]

---

## 💻 Solutions

<details>
<summary>Python</summary>

```python

```
</details>

<details>
<summary>C++</summary>

```cpp

```
</details>

<details>
<summary>Java</summary>

```java

```
</details>

<details>
<summary>JavaScript</summary>

```javascript

```
</details>

