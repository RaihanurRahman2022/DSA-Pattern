# 📚 DSA Pattern: Prefix Sum

## 📖 Pattern Details
[Explain the pattern: when to use, key insights, complexity.]

---

## 📝 Problems
- [Subarray Sum Equals K](https://leetcode.com/problems/subarray-sum-equals-k/)
- [Range Sum Query - Immutable](https://leetcode.com/problems/range-sum-query-immutable/)
- [Continuous Subarray Sum](https://leetcode.com/problems/continuous-subarray-sum/)

---

## 💡 Approach / Notes
[Write general approach and variations here]

---

## 💻 Solutions

<details>
<summary>Python</summary>

```python

```
</details>

<details>
<summary>C++</summary>

```cpp

```
</details>

<details>
<summary>Java</summary>

```java

```
</details>

<details>
<summary>JavaScript</summary>

```javascript

```
</details>

