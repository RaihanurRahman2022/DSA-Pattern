# 📚 DSA Pattern: DFS (Graph & Tree)

## 📖 Pattern Details
[Explain the pattern: when to use, key insights, complexity.]

---

## 📝 Problems
- [Number of Closed Islands](https://leetcode.com/problems/number-of-closed-islands/)
- [Max Area of Island](https://leetcode.com/problems/max-area-of-island/)
- [Clone Graph](https://leetcode.com/problems/clone-graph/)

---

## 💡 Approach / Notes
[Write general approach and variations here]

---

## 💻 Solutions

<details>
<summary>Python</summary>

```python

```
</details>

<details>
<summary>C++</summary>

```cpp

```
</details>

<details>
<summary>Java</summary>

```java

```
</details>

<details>
<summary>JavaScript</summary>

```javascript

```
</details>

