# 📚 DSA Pattern: Bitwise XOR

## 📖 Pattern Details
[Explain the pattern: when to use, key insights, complexity.]

---

## 📝 Problems
- [Single Number](https://leetcode.com/problems/single-number/)
- [Missing Number](https://leetcode.com/problems/missing-number/)
- [Find the Duplicate Number](https://leetcode.com/problems/find-the-duplicate-number/)

---

## 💡 Approach / Notes
[Write general approach and variations here]

---

## 💻 Solutions

<details>
<summary>Python</summary>

```python

```
</details>

<details>
<summary>C++</summary>

```cpp

```
</details>

<details>
<summary>Java</summary>

```java

```
</details>

<details>
<summary>JavaScript</summary>

```javascript

```
</details>

