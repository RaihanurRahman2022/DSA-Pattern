# 📚 DSA Pattern: Overlapping Intervals

## 📖 Pattern Details
[Explain the pattern: when to use, key insights, complexity.]

---

## 📝 Problems
- [Merge Intervals](https://leetcode.com/problems/merge-intervals/)
- [Insert Interval](https://leetcode.com/problems/insert-interval/)
- [Meeting Rooms II](https://leetcode.com/problems/meeting-rooms-ii/)

---

## 💡 Approach / Notes
[Write general approach and variations here]

---

## 💻 Solutions

<details>
<summary>Python</summary>

```python

```
</details>

<details>
<summary>C++</summary>

```cpp

```
</details>

<details>
<summary>Java</summary>

```java

```
</details>

<details>
<summary>JavaScript</summary>

```javascript

```
</details>

